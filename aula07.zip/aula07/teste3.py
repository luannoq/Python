
for n in range(1,10):
    print("Vou mostrar a tabuada do", n)
for multiplo in range(1,10):
    print(n,"x", multiplo, "=", n*multiplo)
    
print("\n------------------\n")    