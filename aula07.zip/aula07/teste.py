for i in range(3,10,2):
    print(i)
    
print("\n--\n") 
   
for i in range (3,10):#atualiza 1 em 1, pois não fornece um "passo"
    print(i)
    
print("\n--\n")  
  
for i in range(10):#valor inicial será 0, pois não informei valor inicial
    print(i) 
      
print("\n--\n")         