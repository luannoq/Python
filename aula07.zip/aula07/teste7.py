compras = []

print("Vamos criar a sua lista de compras!")
print("Quantos itens ela vai ter?")
n = int(input())

for i in range(n):
    #Exercício: Ler por input um item e salvar na lista de compras usando append