compras = ["arroz,", "banana", "tomate"]
for item in compras:
    print("Preciso comprar", item)

compras.append("Uva")    
print("Agora sua lista ficou assim:")
print(compras)