texto1 = "bom dia"
texto2 = "bom dia, estamos na aula de computacional thinking!"
for caractere in texto1:
    print(caractere)
letraA= 0
for caractere in texto2:
    if caractere == "a":
        letraA = letraA + 1 
print("O texto 2 tem", letraA, "a's")     
