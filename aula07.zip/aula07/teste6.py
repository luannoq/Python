linguagens = []#esta lista começa vazia
 
linguagens.extend(["GO", "C++"]) #extend([]) faz com que eu adicione vários itens juntos
linguagens.append("Python")
linguagens.append("Java")
linguagens.append("C#")
#comando len() pega o tamanho de uma sequênica de dados
print("Foram adicionados", len(linguagens),"linguagens")
