print("O programa está começando!")
def exemplo():
    x = 5 #Essa é OUTRA variável, que só existe no escopo da função

x = 3 
exemplo()
print(x) 
#Todas as linhas que n estão dentro de função são executadas (Na ordem que estão escritas)