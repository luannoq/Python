def cumprimenta(nome :str): #Tipo de variável esperada
    #Não preciso criar a variável, só precisa ser chamada para ser criada!
    print("Bom dia,", nome)

cumprimenta("João")
cumprimenta("Aline")