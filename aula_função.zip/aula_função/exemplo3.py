
def exemplo():
    x = 5 #Essa é OUTRA variável, que só existe no escopo da função

def funcao():
    print("Está é uma função do exemplo 3")

def main():
    print("O programa está começando...")
    x = 3 
    exemplo()
    print(x) 

if __name__ == "main":
    main() 