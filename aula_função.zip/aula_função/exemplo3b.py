import exemplo3

print("COMEÇANDO O PROGRAMA...")
exemplo3.funcao()
print("\n TERMINANDO O PROGRAMA.")