def soma(A,B):
    return A + B

def media(A,B):
    return soma(A,B)/2

t = (2 + 7)*3
s = soma(8,10)      #Chama a função "soma", com A = 8, B = 10
x = media(8,10)     #Chama função "media", com A
print(s)
print(x)        



s = (8,10)

soma(*s)
print(soma(*s))