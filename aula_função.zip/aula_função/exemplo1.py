def nome_da_funcao(): #Como fazer uma função
    print("exemplo!")



def outra_funcao():
    print("Esse programa tem 2 funcoes")

outra_funcao()   
print("(terminei a primeira chamada.)") 
nome_da_funcao()   #Chamando uma função   
print("(terminei a segunda chamada)")                                                                                          