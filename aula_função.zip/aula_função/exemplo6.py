def cumprimenta(nome = "pessoa"):
    print("Bom dia," ,nome)

cumprimenta("Aline")    #Inicializa  nome com um parametro chamado "Aline"
cumprimenta()           #Inicializa nome com valor padrão ("pessoa")