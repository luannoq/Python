def soma(A,B):
    return A + B

def media(A,B):
    return soma(A,B)/2

t = (2 + 7)*3
s = (8,10)
x = (8,10)


resultado = soma(*s)
print(res) #Outro jeito de resolver o exemplo 7 #Aqui estou chamando a variável dentro da função soma

soma(*x) # não tem efeito (essa linha podia ser omitida) # O "*" nesse caso é usado só para chamar a variável
print(soma(*x))

soma(*t) # não tem efeito (essa linha podia ser omitida)
print(soma(*t))