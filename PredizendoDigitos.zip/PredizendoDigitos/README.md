#Projeto de ML - treinando um MLP para predizer dígitos np front-end

dadadada

-------

##Executando 

na raíz:

```bash
pip install -r requirements.txt
```