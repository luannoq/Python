from flask import Flask, jsonify, request
from flask_cors import CORS

import numpy as np
import pickle
import matplotlib.pyplot as plt 

app = Flask(__name__) #criando a aplicação 
CORS(app) # corrigir possiveis problemas de cross-origin (navegador)

#como funciona o flask: crio funções e uso o magic decoration @app.route para 
#associar uma url a ela

@app.route('/teste')
def teste():
    return "Server is up!"
