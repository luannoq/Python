
        
'''Exercício: crie (usando compreensão de lista):
    (a) temperatura_altas, contendo as temperaturas acima de 90
    (b) temperatura_muito_altas, contendo as temperaturas acima de 100
    
    Depois vamos ver o tamanho dessas listas comparadas com a lista total
    de temperaturas, para ver qual proporção do tempo está em temperatura alta
'''             
        
        
temperaturas = []
with open ('dados.txt') as arquivo:
    for linha in arquivo:
        temperaturas.append(float(linha)) #Lê o txt como float, inicialmente vem como txt.

temperaturasAltas = []
temperaturasMuitoAltas = []
        
for temperatura in temperaturas:
    if temperatura > 90 and temperatura < 100:
        temperaturasAltas.append(temperatura)
    elif temperatura > 100:
        temperaturasMuitoAltas.append(temperatura)
        
resp = int(input("Digite 1- Para temperaturas altas ou 2- Para temperaturas muito altas."))
if resp == 1:
    print(temperaturasAltas)
elif resp == 2:
    print(temperaturasMuitoAltas)    
             