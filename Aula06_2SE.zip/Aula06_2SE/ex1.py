#lista = []
#for VARIAVEL in SEQUENCIA:
#if CONDICAO:
#lista.append(EXPRESSAO)
# (o if é opcional, para caso queiramos algum filtro)    

#lista = [EXPRESSAO for VARIAVEL in SEQUENCIA if CONDICAO]    

#EXEMPLO

'''EXERCÍCIO: transformar a linha 11 (logo acima) em bloco de código com for
e append explícitos.
'''
valores = [3, 10, -6, 8, 47, 0, 5, 11, 9]
menoresQue10 = [valor for valor in valores if valor < 10]

menoresQue10=[]
for numeros in valores:
    if numeros < 10:
       menoresQue10.append(numeros)
print(menoresQue10)