DROP TABLE funcionarios

CREATE TABLE funcionarios(
    id int PRIMARY KEY,
    nm_funcionario varchar2(100)NOT NULL ,
    ano_ingresso int
);

INSERT INTO funcionarios(id, nm_funcionario, ano_ingresso)
VALUES (1,'Matheusa', 2021);

SELECT * FROM funcionarios;