#Devolve True, se n é número par; False, caso contrário

def primo(n):
    if n <= 1:
        return False
   
    for possivel_divisor in range(2, n):
        if n % possivel_divisor == 0:
            #Eccontrei divisor de n! Entãon não é primo
            return False
    return True

for i in range(1, 100):
    if primo(i) == True:
        print(i)

