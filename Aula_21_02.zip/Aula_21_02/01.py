

print("Digite um número positivo.")
N = int(input())
i = 0
while i <= N:
    print(i)
    i = i+2


#for i in range (0, N+1, 2):
    #print(i)